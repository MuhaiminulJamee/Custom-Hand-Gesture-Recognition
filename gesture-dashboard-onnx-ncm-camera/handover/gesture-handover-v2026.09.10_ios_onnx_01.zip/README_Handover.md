﻿# iOS ONNX Handover (8 gestures)

## What is included
- gesture_mlp_production.onnx (main model)
- gesture_mlp_onnx_metadata.json
- gesture_mobile_runtime_config.json
- gesture_artifact_manifest.json

## How to consume
Use ONNX Runtime for iOS with input/output tensor shape from model metadata.
Consume only: runtime_action from runtime prediction payload.

## Notes
- Cooldown + edge filtering logic should stay consistent with current runtime behavior.
- Do not use .bat scripts in mobile integration.
